@echo off
title Install Pallet Builder Clean
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup\install.ps1"
if errorlevel 1 goto manual
pause
exit /b 0

:manual
echo.
echo   The automatic install was blocked on this PC.
echo   You can still use Pallet Builder Clean:
echo     1. Copy the "app" folder to your Documents (or anywhere you like).
echo     2. Open "Pallet Builder Clean.html" in that folder (Edge or Chrome).
echo     3. To make a desktop icon: right-click "Pallet Builder Clean.html",
echo        Send to, Desktop (create shortcut). See "Read Me.txt" for the icon.
echo.
pause
