# Pallet Builder Clean installer: copies the program to this user's AppData and makes desktop + Start menu shortcuts
# with the Pallet Builder Clean icon. No admin rights needed. After this, it updates itself from the shared copy online.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$src  = Join-Path $root 'app'
$dest = Join-Path $env:LOCALAPPDATA 'Pallet Builder Clean'
Write-Host ''
Write-Host '  Installing Pallet Builder Clean...'
New-Item -ItemType Directory -Force -Path $dest | Out-Null
# keep a newer program that this PC already downloaded
$have = [int64]0; $bf = Join-Path $dest 'build.txt'
if (Test-Path $bf) { [int64]::TryParse((Get-Content $bf -TotalCount 1), [ref]$have) | Out-Null }
$mine = [int64](Get-Content (Join-Path $src 'build.txt') -TotalCount 1)
Get-ChildItem $src | ForEach-Object {
  if ($have -gt $mine -and ($_.Name -eq 'Pallet Builder Clean.html' -or $_.Name -eq 'build.txt')) { return }
  Copy-Item $_.FullName -Destination $dest -Recurse -Force
}
foreach ($f in @('uninstall.ps1', 'open.ps1', 'launch.vbs')) { Copy-Item -Path (Join-Path $PSScriptRoot $f) -Destination $dest -Force }
Copy-Item -Path (Join-Path $root 'Uninstall Pallet Builder Clean.bat') -Destination $dest -Force
$ico = Join-Path $dest 'Pallet Builder Clean.ico'
$shell   = New-Object -ComObject WScript.Shell
$desktop = [Environment]::GetFolderPath('Desktop')
$menu    = [Environment]::GetFolderPath('Programs')
foreach ($lnk in @((Join-Path $desktop 'Pallet Builder Clean.lnk'), (Join-Path $menu 'Pallet Builder Clean.lnk'))) {
  $s = $shell.CreateShortcut($lnk)
  $s.TargetPath       = Join-Path $env:SystemRoot 'System32\wscript.exe'
  $s.Arguments        = '"' + (Join-Path $dest 'launch.vbs') + '"'
  $s.WorkingDirectory = $dest
  $s.IconLocation     = $ico + ',0'
  $s.Description      = 'Pallet Builder Clean'
  $s.Save()
}
$u = $shell.CreateShortcut((Join-Path $menu 'Uninstall Pallet Builder Clean.lnk'))
$u.TargetPath = Join-Path $dest 'Uninstall Pallet Builder Clean.bat'
$u.WorkingDirectory = $dest
$u.IconLocation = $ico + ',0'
$u.Save()
Write-Host ''
Write-Host '  Done! Pallet Builder Clean is installed.'
Write-Host '  Open it with the Pallet Builder Clean icon on your desktop or in the Start menu.'
Write-Host '  From now on it updates itself each time it opens (when the PC is online).'
Write-Host ''
