# Pallet Builder Clean uninstaller: removes the shortcuts and the installed program files.
$ErrorActionPreference = 'SilentlyContinue'
$dest    = Join-Path $env:LOCALAPPDATA 'Pallet Builder Clean'
$desktop = [Environment]::GetFolderPath('Desktop')
$menu    = [Environment]::GetFolderPath('Programs')
Remove-Item (Join-Path $desktop 'Pallet Builder Clean.lnk') -Force
Remove-Item (Join-Path $menu 'Pallet Builder Clean.lnk') -Force
Remove-Item (Join-Path $menu 'Uninstall Pallet Builder Clean.lnk') -Force
Write-Host ''
Write-Host '  Pallet Builder Clean has been removed from this PC.'
Write-Host ''
# The folder holds this script, so remove it after we exit.
$cmd = '/c ping -n 6 127.0.0.1 >nul & rmdir /s /q "' + $dest + '"'
Start-Process -WindowStyle Hidden -FilePath 'cmd.exe' -ArgumentList $cmd
