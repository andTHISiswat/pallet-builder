# Pallet Builder Clean: check the shared copy online for a newer program, then open it in its own window.
# If this PC can't reach the internet, it just opens the copy it already has.
$ErrorActionPreference = 'SilentlyContinue'
$ProgressPreference    = 'SilentlyContinue'
$dir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$html  = Join-Path $dir 'Pallet Builder Clean.html'
$bfile = Join-Path $dir 'build.txt'
$url   = Get-Content (Join-Path $dir 'update-url.txt') -TotalCount 1
if ($url) {
  try {
    [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
    $v = (Invoke-WebRequest -Uri ($url + 'version.json?t=' + [DateTime]::UtcNow.Ticks) -UseBasicParsing -TimeoutSec 4).Content | ConvertFrom-Json
    $have = [int64]0; if (Test-Path $bfile) { [int64]::TryParse((Get-Content $bfile -TotalCount 1), [ref]$have) | Out-Null }
    if ([int64]$v.build -gt $have) {
      $tmp = Join-Path $env:TEMP ('pallet-builder-' + $v.build + '.html')
      Invoke-WebRequest -Uri ($url + 'Pallet-Builder.html?t=' + [DateTime]::UtcNow.Ticks) -OutFile $tmp -UseBasicParsing -TimeoutSec 180
      # only swap it in if the whole file came down and it's the right build
      if ((Test-Path $tmp) -and (Get-Item $tmp).Length -gt 1000000 -and (Select-String -Path $tmp -SimpleMatch ('window.PB_BUILD = ' + $v.build + ';') -Quiet)) {
        Copy-Item $tmp $html -Force
        Set-Content -Path $bfile -Value $v.build
      }
      Remove-Item $tmp -Force
    }
  } catch {}
}
$bases = @(${env:ProgramFiles(x86)}, $env:ProgramFiles, $env:LOCALAPPDATA) | Where-Object { $_ }
$apps  = @('Microsoft\Edge\Application\msedge.exe', 'Google\Chrome\Application\chrome.exe')
$browser = $null
foreach ($a in $apps) { foreach ($b in $bases) { $c = Join-Path $b $a; if (-not $browser -and (Test-Path $c)) { $browser = $c } } }
$uri = ([System.Uri]$html).AbsoluteUri
if ($browser) { Start-Process -FilePath $browser -ArgumentList ('--app="' + $uri + '"') } else { Start-Process $html }
