window.PB_PROFILE = {"prefix": "pbc-", "updateUrl": "https://raw.githubusercontent.com/andTHISiswat/pallet-builder/main/"};
