@echo off
title Uninstall Pallet Builder Clean
set "HERE=%~dp0"
cd /d "%TEMP%"
set "PS1=%HERE%uninstall.ps1"
if not exist "%PS1%" set "PS1=%HERE%setup\uninstall.ps1"
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%"
pause
